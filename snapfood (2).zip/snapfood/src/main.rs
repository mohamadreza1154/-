mod models;
mod handlers;
mod admin;

use std::io;

fn main() {
    loop {
        println!("Welcome to the Snapfood CLI System");
        println!("1. Login");
        println!("2. Register");
        println!("3. Exit");

        let mut choice = String::new();
        io::stdin().read_line(&mut choice).unwrap();

        match choice.trim() {
            "1" => handlers::login(),
            "2" => handlers::register(),
            "3" => {
                println!("Exiting...");
                break;
            }
            _ => println!("Invalid option."),
        }
    }
}