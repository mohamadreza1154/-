use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize, Clone)]
pub struct User {
    pub username: String,
    pub password: String,
    pub role: String,
    pub orders: Option<Vec<Order>>,
    pub restaurant: Option<String>,
    pub is_blocked: bool,
}

#[derive(Serialize, Deserialize, Clone)]
pub struct Restaurant {
    pub name: String,
    pub owner: String,
    pub category: String,
    pub menu: Vec<MenuItem>,
    pub is_blocked: bool,
}

#[derive(Serialize, Deserialize, Clone)]
pub struct MenuItem {
    pub name: String,
    pub price: u32,
}

#[derive(Serialize, Deserialize, Clone)]
pub struct Order {
    pub username: String,
    pub restaurant: String,
    pub items: Vec<OrderItem>,
    pub total_price: u32,
    pub datetime: String,
    pub status: String,
}

#[derive(Serialize, Deserialize, Clone)]
pub struct OrderItem {
    pub name: String,
    pub quantity: u32,
}