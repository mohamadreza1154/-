use crate::models::{User, Restaurant, Order, MenuItem, OrderItem};
use std::fs::{read_to_string, write, create_dir_all};
use std::io::{self, Write};
use std::path::Path;
use chrono::Local;
use serde_json;

pub fn register() {
    let mut username = String::new();
    let mut password = String::new();
    let mut role = String::new();

    print!("Enter username: ");
    io::stdout().flush().unwrap();
    io::stdin().read_line(&mut username).unwrap();

    print!("Enter password: ");
    io::stdout().flush().unwrap();
    io::stdin().read_line(&mut password).unwrap();

    print!("Enter role (user / restaurant_owner): ");
    io::stdout().flush().unwrap();
    io::stdin().read_line(&mut role).unwrap();

    let role = role.trim().to_lowercase();
    let restaurant = if role == "restaurant_owner" {
        print!("Enter restaurant name: ");
        io::stdout().flush().unwrap();
        let mut restaurant_name = String::new();
        io::stdin().read_line(&mut restaurant_name).unwrap();

        print!("Enter restaurant category (e.g., Fastfood, Iranian): ");
        io::stdout().flush().unwrap();
        let mut category = String::new();
        io::stdin().read_line(&mut category).unwrap();

        let mut restaurants: Vec<Restaurant> = if Path::new("data/restaurants.json").exists() {
            let data = read_to_string("data/restaurants.json").unwrap();
            serde_json::from_str(&data).unwrap_or_else(|_| vec![])
        } else {
            vec![]
        };
        restaurants.push(Restaurant {
            name: restaurant_name.trim().to_string(),
            owner: username.trim().to_string(),
            category: category.trim().to_string(),
            menu: vec![],
            is_blocked: false,
        });
        let json = serde_json::to_string_pretty(&restaurants).unwrap();
        write("data/restaurants.json", json).unwrap();
        Some(restaurant_name.trim().to_string())
    } else {
        None
    };

    let new_user = User {
        username: username.trim().to_string(),
        password: password.trim().to_string(),
        role,
        orders: Some(vec![]),
        restaurant,
        is_blocked: false,
    };

    create_dir_all("data").unwrap();
    let path = "data/users.json";
    let mut users: Vec<User> = if Path::new(path).exists() {
        let data = read_to_string(path).unwrap();
        serde_json::from_str(&data).unwrap_or_else(|_| vec![])
    } else {
        vec![]
    };
    users.push(new_user);
    let json = serde_json::to_string_pretty(&users).unwrap();
    write(path, json).unwrap();

    println!("Registration successful.");
}

pub fn login() {
    let mut username = String::new();
    let mut password = String::new();

    print!("Username: ");
    io::stdout().flush().unwrap();
    io::stdin().read_line(&mut username).unwrap();

    print!("Password: ");
    io::stdout().flush().unwrap();
    io::stdin().read_line(&mut password).unwrap();

    let path = "data/users.json";
    let data = read_to_string(path).unwrap_or(String::new());
    let users: Vec<User> = serde_json::from_str(&data).unwrap_or(vec![]);

    for user in users {
        if user.username == username.trim() && user.password == password.trim() && !user.is_blocked {
            println!("Login successful. Role: {}", user.role);
            match user.role.as_str() {
                "admin" => crate::admin::admin_panel(),
                "user" => user_panel(&user),
                "restaurant_owner" => restaurant_owner_panel(&user),
                _ => println!("Unknown role."),
            }
            return;
        }
    }
    println!("Invalid credentials or account is blocked.");
}

fn user_panel(user: &User) {
    loop {
        println!("\nUser Menu");
        println!("1. View Restaurants");
        println!("2. Place Order");
        println!("3. View Order History");
        println!("4. Back");

        let mut input = String::new();
        io::stdin().read_line(&mut input).unwrap();

        match input.trim() {
            "1" => view_restaurants(),
            "2" => place_order(user),
            "3" => view_order_history(user),
            "4" => break,
            _ => println!("Invalid choice."),
        }
    }
}

fn restaurant_owner_panel(user: &User) {
    loop {
        println!("\nRestaurant Owner Menu");
        println!("1. View Menu");
        println!("2. Add Menu Item");
        println!("3. Edit Menu Item");
        println!("4. Delete Menu Item");
        println!("5. View Orders");
        println!("6. View Order History");
        println!("7. Back");

        let mut input = String::new();
        io::stdin().read_line(&mut input).unwrap();

        match input.trim() {
            "1" => view_restaurant_menu(user),
            "2" => add_menu_item(user),
            "3" => edit_menu_item(user),
            "4" => delete_menu_item(user),
            "5" => view_orders(user),
            "6" => view_order_history_for_restaurant(user),
            "7" => break,
            _ => println!("Invalid choice."),
        }
    }
}

fn view_restaurants() {
    let data = read_to_string("data/restaurants.json").unwrap_or(String::new());
    let restaurants: Vec<Restaurant> = serde_json::from_str(&data).unwrap_or(vec![]);
    if restaurants.is_empty() {
        println!("No restaurants available.");
        return;
    }
    println!("Restaurants by Category:");
    for res in restaurants {
        if !res.is_blocked {
            println!("- {} ({})", res.name, res.category);
            for item in &res.menu {
                println!("  - {}: {} IRR", item.name, item.price);
            }
        }
    }
}


fn place_order(user: &User) {
    let data = read_to_string("data/restaurants.json").unwrap_or(String::new());
    let restaurants: Vec<Restaurant> = serde_json::from_str(&data).unwrap_or(vec![]);
    if restaurants.is_empty() {
        println!("No restaurants available.");
        return;
    }

    println!("Available Restaurants:");
    for (i, res) in restaurants.iter().enumerate() {
        if !res.is_blocked {
            println!("{}. {} ({})", i + 1, res.name, res.category);
        }
    }

    print!("Enter restaurant number: ");
    io::stdout().flush().unwrap();
    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();
    let index: usize = input.trim().parse().unwrap_or(0);
    let valid_restaurants: Vec<&Restaurant> = restaurants.iter().filter(|r| !r.is_blocked).collect();
    if index == 0 || index > valid_restaurants.len() {
        println!("Invalid restaurant number!");
        return;
    }
    let restaurant = valid_restaurants[index - 1];


    let mut cart: Vec<OrderItem> = vec![];
    let mut total_price: u32 = 0;

    loop {
        println!("\nMenu for {}:", restaurant.name);
        for (i, item) in restaurant.menu.iter().enumerate() {
            println!("{}. {}: {} IRR", i + 1, item.name, item.price);
        }

        print!("Enter item number (or 0 to finish): ");
        io::stdout().flush().unwrap();
        let mut input = String::new();
        io::stdin().read_line(&mut input).unwrap();
        let item_index: usize = input.trim().parse().unwrap_or(0);


        if item_index == 0 {
            if cart.is_empty() {
                println!("Your cart is empty. Order cancelled.");
                return;
            }
            break;
        }

        if item_index > restaurant.menu.len() {
            println!("Invalid item number!");
            continue;
        }
        let item = &restaurant.menu[item_index - 1];

        print!("Enter quantity: ");
        io::stdout().flush().unwrap();
        let mut quantity = String::new();
        io::stdin().read_line(&mut quantity).unwrap();
        let quantity: u32 = quantity.trim().parse().unwrap_or(1);


        let order_item = OrderItem {
            name: item.name.clone(),
            quantity,
        };
        cart.push(order_item);
        total_price += item.price * quantity;

        println!("Added {} (x{}) to cart. Current total: {} IRR", item.name, quantity, total_price);
    }


    println!("\nYour Cart:");
    for item in &cart {
        println!("- {} (x{})", item.name, item.quantity);
    }
    println!("Total: {} IRR", total_price);

    let order = Order {
        username: user.username.clone(),
        restaurant: restaurant.name.clone(),
        items: cart,
        total_price,
        datetime: Local::now().to_string(),
        status: "pending".to_string(),
    };

    let path = "data/orders.json";
    let mut orders: Vec<Order> = if Path::new(path).exists() {
        let data = read_to_string(path).unwrap();
        serde_json::from_str(&data).unwrap_or(vec![])
    } else {
        vec![]
    };
    orders.push(order);
    let json = serde_json::to_string_pretty(&orders).unwrap();
    write(path, json).unwrap();

    println!("Order placed successfully! Total: {} IRR", total_price);
}

fn view_order_history(user: &User) {
    let data = read_to_string("data/orders.json").unwrap_or(String::new());
    let orders: Vec<Order> = serde_json::from_str(&data).unwrap_or(vec![]);
    let user_orders: Vec<&Order> = orders.iter().filter(|o| o.username == user.username).collect();
    if user_orders.is_empty() {
        println!("No orders found.");
        return;
    }
    println!("Order History for {}:", user.username);
    for order in user_orders {
        println!("- Date: {}, Restaurant: {}, Total: {} IRR, Status: {}",
                 order.datetime, order.restaurant, order.total_price, order.status);
        for item in &order.items {
            println!("  - {} (x{})", item.name, item.quantity);
        }
    }
}

fn view_restaurant_menu(user: &User) {
    let data = read_to_string("data/restaurants.json").unwrap_or(String::new());
    let restaurants: Vec<Restaurant> = serde_json::from_str(&data).unwrap_or(vec![]);
    if let Some(restaurant) = restaurants.iter().find(|r| r.owner == user.username && !r.is_blocked) {
        println!("Menu for {}:", restaurant.name);
        for item in &restaurant.menu {
            println!("- {}: {} IRR", item.name, item.price);
        }
    } else {
        println!("No restaurant found for this owner or it is blocked.");
    }
}

fn add_menu_item(user: &User) {
    let path = "data/restaurants.json";
    let mut restaurants: Vec<Restaurant> = if Path::new(path).exists() {
        let data = read_to_string(path).unwrap();
        serde_json::from_str(&data).unwrap_or(vec![])
    } else {
        vec![]
    };

    let restaurant = restaurants.iter_mut().find(|r| r.owner == user.username && !r.is_blocked);
    if restaurant.is_none() {
        println!("No restaurant found for this owner or it is blocked.");
        return;
    }
    let restaurant = restaurant.unwrap();

    print!("Enter item name: ");
    io::stdout().flush().unwrap();
    let mut item_name = String::new();
    io::stdin().read_line(&mut item_name).unwrap();

    print!("Enter item price: ");
    io::stdout().flush().unwrap();
    let mut price = String::new();
    io::stdin().read_line(&mut price).unwrap();
    let price: u32 = price.trim().parse().unwrap_or(0);

    restaurant.menu.push(MenuItem {
        name: item_name.trim().to_string(),
        price,
    });

    let json = serde_json::to_string_pretty(&restaurants).unwrap();
    write(path, json).unwrap();

    println!("Menu item added successfully.");
}

fn edit_menu_item(user: &User) {
    let path = "data/restaurants.json";
    let mut restaurants: Vec<Restaurant> = if Path::new(path).exists() {
        let data = read_to_string(path).unwrap();
        serde_json::from_str(&data).unwrap_or(vec![])
    } else {
        vec![]
    };

    let restaurant = restaurants.iter_mut().find(|r| r.owner == user.username && !r.is_blocked);
    if restaurant.is_none() {
        println!("No restaurant found for this owner or it is blocked.");
        return;
    }
    let restaurant = restaurant.unwrap();

    println!("Menu for {}:", restaurant.name);
    for (i, item) in restaurant.menu.iter().enumerate() {
        println!("{}. {}: {} IRR", i + 1, item.name, item.price);
    }

    print!("Enter item number to edit: ");
    io::stdout().flush().unwrap();
    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();
    let index: usize = input.trim().parse().unwrap_or(0);
    if index == 0 || index > restaurant.menu.len() {
        println!("Invalid item number.");
        return;
    }

    print!("Enter new item name: ");
    io::stdout().flush().unwrap();
    let mut item_name = String::new();
    io::stdin().read_line(&mut item_name).unwrap();

    print!("Enter new item price: ");
    io::stdout().flush().unwrap();
    let mut price = String::new();
    io::stdin().read_line(&mut price).unwrap();
    let price: u32 = price.trim().parse().unwrap_or(0);

    restaurant.menu[index - 1] = MenuItem {
        name: item_name.trim().to_string(),
        price,
    };

    let json = serde_json::to_string_pretty(&restaurants).unwrap();
    write(path, json).unwrap();

    println!("Menu item edited successfully.");
}

fn delete_menu_item(user: &User) {
    let path = "data/restaurants.json";
    let mut restaurants: Vec<Restaurant> = if Path::new(path).exists() {
        let data = read_to_string(path).unwrap();
        serde_json::from_str(&data).unwrap_or(vec![])
    } else {
        vec![]
    };

    let restaurant = restaurants.iter_mut().find(|r| r.owner == user.username && !r.is_blocked);
    if restaurant.is_none() {
        println!("No restaurant found for this owner or it is blocked.");
        return;
    }
    let restaurant = restaurant.unwrap();

    println!("Menu for {}:", restaurant.name);
    for (i, item) in restaurant.menu.iter().enumerate() {
        println!("{}. {}: {} IRR", i + 1, item.name, item.price);
    }

    print!("Enter item number to delete: ");
    io::stdout().flush().unwrap();
    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();
    let index: usize = input.trim().parse().unwrap_or(0);
    if index == 0 || index > restaurant.menu.len() {
        println!("Invalid item number.");
        return;
    }

    restaurant.menu.remove(index - 1);
    let json = serde_json::to_string_pretty(&restaurants).unwrap();
    write(path, json).unwrap();

    println!("Menu item deleted successfully.");
}

fn view_orders(user: &User) {
    let data = read_to_string("data/orders.json").unwrap_or(String::new());
    let orders: Vec<Order> = serde_json::from_str(&data).unwrap_or(vec![]);
    let restaurants: Vec<Restaurant> = if Path::new("data/restaurants.json").exists() {
        let data = read_to_string("data/restaurants.json").unwrap();
        serde_json::from_str(&data).unwrap_or(vec![])
    } else {
        vec![]
    };
    let restaurant = restaurants.iter().find(|r| r.owner == user.username && !r.is_blocked);
    if restaurant.is_none() {
        println!("No restaurant found for this owner or it is blocked.");
        return;
    }
    let restaurant = restaurant.unwrap();

    let user_orders: Vec<&Order> = orders.iter().filter(|o| o.restaurant == restaurant.name).collect();
    if user_orders.is_empty() {
        println!("No orders found for your restaurant.");
        return;
    }
    println!("Orders for {}:", restaurant.name);
    for order in user_orders {
        println!("- Date: {}, User: {}, Total: {} IRR, Status: {}",
                 order.datetime, order.username, order.total_price, order.status);
        for item in &order.items {
            println!("  - {} (x{})", item.name, item.quantity);
        }
    }
}

fn view_order_history_for_restaurant(user: &User) {
    let data = read_to_string("data/orders.json").unwrap_or(String::new());
    let orders: Vec<Order> = serde_json::from_str(&data).unwrap_or(vec![]);
    let restaurants: Vec<Restaurant> = if Path::new("data/restaurants.json").exists() {
        let data = read_to_string("data/restaurants.json").unwrap();
        serde_json::from_str(&data).unwrap_or(vec![])
    } else {
        vec![]
    };
    let restaurant = restaurants.iter().find(|r| r.owner == user.username && !r.is_blocked);
    if restaurant.is_none() {
        println!("No restaurant found for this owner or it is blocked.");
        return;
    }
    let restaurant = restaurant.unwrap();

    let user_orders: Vec<&Order> = orders.iter().filter(|o| o.restaurant == restaurant.name).collect();
    if user_orders.is_empty() {
        println!("No order history found for your restaurant.");
        return;
    }
    println!("Order History for {}:", restaurant.name);
    for order in user_orders {
        println!("- Date: {}, User: {}, Total: {} IRR, Status: {}",
                 order.datetime, order.username, order.total_price, order.status);
        for item in &order.items {
            println!("  - {} (x{})", item.name, item.quantity);
        }
    }
}