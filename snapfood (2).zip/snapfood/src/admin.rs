use crate::models::{User, Restaurant, Order};
use std::fs;
use std::io::{self, Write};
use std::path::Path;

pub fn admin_panel() {
    loop {
        println!("Admin Panel");
        println!("1. View Users");
        println!("2. View Restaurants");
        println!("3. View Orders");
        println!("4. Delete User");
        println!("5. Delete Restaurant");
        println!("6. Block/Unblock User");
        println!("7. Block/Unblock Restaurant");
        println!("8. Back");

        let mut input = String::new();
        io::stdin().read_line(&mut input).unwrap();

        match input.trim() {
            "1" => view_users(),
            "2" => view_restaurants(),
            "3" => view_orders(),
            "4" => delete_user(),
            "5" => delete_restaurant(),
            "6" => block_unblock_user(),
            "7" => block_unblock_restaurant(),
            "8" => break,
            _ => println!("Invalid choice."),
        }
    }
}

fn view_users() {
    let data = match fs::read_to_string("data/users.json") {
        Ok(content) => content,
        Err(e) => {
            println!("Error reading users.json: {}", e);
            return;
        }
    };
    let users: Vec<User> = serde_json::from_str(&data).unwrap_or_else(|e| {
        println!("Error parsing users.json: {}", e);
        vec![]
    });
    for user in users {
        println!("Username: {}, Role: {}, Blocked: {}", user.username, user.role, user.is_blocked);
    }
}

fn view_restaurants() {
    let data = match fs::read_to_string("data/restaurants.json") {
        Ok(content) => content,
        Err(e) => {
            println!("Error reading restaurants.json: {}", e);
            return;
        }
    };
    let restaurants: Vec<Restaurant> = serde_json::from_str(&data).unwrap_or_else(|e| {
        println!("Error parsing restaurants.json: {}", e);
        vec![]
    });
    for res in restaurants {
        println!("Restaurant: {}, Owner: {}, Category: {}, Blocked: {}", res.name, res.owner, res.category, res.is_blocked);
    }
}

fn view_orders() {
    let data = match fs::read_to_string("data/orders.json") {
        Ok(content) => content,
        Err(e) => {
            println!("Error reading orders.json: {}", e);
            return;
        }
    };
    let orders: Vec<Order> = serde_json::from_str(&data).unwrap_or_else(|e| {
        println!("Error parsing orders.json: {}", e);
        vec![]
    });
    for ord in orders {
        println!("Order by {} at {} - Total: {} IRR, Status: {}", ord.username, ord.datetime, ord.total_price, ord.status);
    }
}

fn delete_user() {
    print!("Enter username to delete: ");
    io::stdout().flush().unwrap();
    let mut username = String::new();
    io::stdin().read_line(&mut username).unwrap();
    let username = username.trim();

    let path = "data/users.json";
    let mut users: Vec<User> = if Path::new(path).exists() {
        let data = fs::read_to_string(path).unwrap_or_else(|e| {
            println!("Error reading users.json: {}", e);
            String::new()
        });
        serde_json::from_str(&data).unwrap_or_else(|e| {
            println!("Error parsing users.json: {}", e);
            vec![]
        })
    } else {
        vec![]
    };
    let initial_len = users.len();
    users.retain(|u| u.username != username);
    if users.len() == initial_len {
        println!("User not found.");
        return;
    }
    let json = serde_json::to_string_pretty(&users).unwrap();
    fs::write(path, json).unwrap_or_else(|e| println!("Error writing users.json: {}", e));
    println!("User deleted successfully.");
}

fn delete_restaurant() {
    print!("Enter restaurant name to delete: ");
    io::stdout().flush().unwrap();
    let mut name = String::new();
    io::stdin().read_line(&mut name).unwrap();
    let name = name.trim();

    let path = "data/restaurants.json";
    let mut restaurants: Vec<Restaurant> = if Path::new(path).exists() {
        let data = fs::read_to_string(path).unwrap_or_else(|e| {
            println!("Error reading restaurants.json: {}", e);
            String::new()
        });
        serde_json::from_str(&data).unwrap_or_else(|e| {
            println!("Error parsing restaurants.json: {}", e);
            vec![]
        })
    } else {
        vec![]
    };
    let initial_len = restaurants.len();
    restaurants.retain(|r| r.name != name);
    if restaurants.len() == initial_len {
        println!("Restaurant not found.");
        return;
    }
    let json = serde_json::to_string_pretty(&restaurants).unwrap();
    fs::write(path, json).unwrap_or_else(|e| println!("Error writing restaurants.json: {}", e));
    println!("Restaurant deleted successfully.");
}

fn block_unblock_user() {
    print!("Enter username to block/unblock: ");
    io::stdout().flush().unwrap();
    let mut username = String::new();
    io::stdin().read_line(&mut username).unwrap();
    let username = username.trim();

    let path = "data/users.json";
    let mut users: Vec<User> = if Path::new(path).exists() {
        let data = fs::read_to_string(path).unwrap_or_else(|e| {
            println!("Error reading users.json: {}", e);
            String::new()
        });
        serde_json::from_str(&data).unwrap_or_else(|e| {
            println!("Error parsing users.json: {}", e);
            vec![]
        })
    } else {
        vec![]
    };
    if let Some(user) = users.iter_mut().find(|u| u.username == username) {
        user.is_blocked = !user.is_blocked;
        println!("User {} is now {}", username, if user.is_blocked { "blocked" } else { "unblocked" });
    } else {
        println!("User not found.");
        return;
    }
    let json = serde_json::to_string_pretty(&users).unwrap();
    fs::write(path, json).unwrap_or_else(|e| println!("Error writing users.json: {}", e));
}

fn block_unblock_restaurant() {
    print!("Enter restaurant name to block/unblock: ");
    io::stdout().flush().unwrap();
    let mut name = String::new();
    io::stdin().read_line(&mut name).unwrap();
    let name = name.trim();

    let path = "data/restaurants.json";
    let mut restaurants: Vec<Restaurant> = if Path::new(path).exists() {
        let data = fs::read_to_string(path).unwrap_or_else(|e| {
            println!("Error reading restaurants.json: {}", e);
            String::new()
        });
        serde_json::from_str(&data).unwrap_or_else(|e| {
            println!("Error parsing restaurants.json: {}", e);
            vec![]
        })
    } else {
        vec![]
    };
    if let Some(restaurant) = restaurants.iter_mut().find(|r| r.name == name) {
        restaurant.is_blocked = !restaurant.is_blocked;
        println!("Restaurant {} is now {}", name, if restaurant.is_blocked { "blocked" } else { "unblocked" });
    } else {
        println!("Restaurant not found.");
        return;
    }
    let json = serde_json::to_string_pretty(&restaurants).unwrap();
    fs::write(path, json).unwrap_or_else(|e| println!("Error writing restaurants.json: {}", e));
}